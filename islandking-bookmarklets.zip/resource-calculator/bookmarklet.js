/*
 * Islandking Ressourcenrechner — Bookmarklet
 * Läuft same-origin auf islandking.ch (Panel-Overlay), keine Installation.
 * Nutzt den vorhandenen /api/islands/:id/tech-path Endpoint, der bereits die
 * volle Voraussetzungskette (Gebäude/Forschung/Schiff) inkl. Gesamtkosten
 * und Bauzeit liefert — wir rechnen nur noch die Ansparzeit aus Lager +
 * Produktion/h dazu.
 */
(function () {
  const VERSION = 'v4-2026-09-11';
  const existing = document.getElementById('ikrc-panel');
  if (existing) { existing.remove(); return; }

  const token = localStorage.getItem('access_token');
  if (!token) { alert('Kein access_token gefunden — bist du auf islandking.ch eingeloggt?'); return; }

  const authFetch = (url) => fetch(url, { headers: { Authorization: 'Bearer ' + token } }).then(r => {
    if (!r.ok) throw new Error('HTTP ' + r.status + ' bei ' + url);
    return r.json();
  });

  const RES = [
    ['wood', '🪵 Holz'],
    ['stone', '🪨 Stein'],
    ['iron', '⚙️ Eisen'],
    ['coal', '🪨 Kohle'],
  ];

  function fmtDuration(totalSeconds) {
    if (!isFinite(totalSeconds)) return 'nie (Produktion = 0)';
    if (totalSeconds <= 0) return 'sofort';
    const d = Math.floor(totalSeconds / 86400);
    const h = Math.floor((totalSeconds % 86400) / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    return (d ? d + 'd ' : '') + (h ? h + 'h ' : '') + m + 'm';
  }

  function fmtHHMM(totalSeconds) {
    if (!isFinite(totalSeconds)) return '';
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    return h + 'h ' + String(m).padStart(2, '0') + 'm';
  }

  // Gemeinsame Stapel-Konvention aller islandking.ch-Bookmarklets: jedes
  // Panel traegt data-ikbm-panel und reiht sich beim Oeffnen unter das
  // unterste bereits offene Panel ein (Islandking Alliance Status
  // Bookmarklet nutzt dieselbe Funktion) - verhindert, dass zwei
  // gleichzeitig geoeffnete Bookmarklets exakt uebereinander liegen.
  function computeStackTop() {
    const others = document.querySelectorAll('[data-ikbm-panel]');
    let maxBottom = 70;
    others.forEach((el) => { maxBottom = Math.max(maxBottom, el.getBoundingClientRect().bottom); });
    return Math.round(others.length ? maxBottom + 12 : maxBottom);
  }

  const panel = document.createElement('div');
  panel.id = 'ikrc-panel';
  panel.dataset.ikbmPanel = '1';
  panel.style.cssText = 'position:fixed;top:' + computeStackTop() + 'px;right:20px;width:380px;max-height:80vh;overflow:auto;'
    + 'background:#0f1f33;color:#e6edf3;border:1px solid #2a4365;border-radius:8px;'
    + 'font:13px/1.4 system-ui,sans-serif;padding:14px;z-index:999999;box-shadow:0 8px 24px rgba(0,0,0,.5)';
  panel.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">'
    + '<b>🏝️ Ressourcenrechner <span style="opacity:.5;font-weight:normal;font-size:11px">' + VERSION + '</span></b>'
    + '<span id="ikrc-close" style="cursor:pointer;opacity:.7">✕</span></div>'
    + '<div id="ikrc-body">Lade Inseln…</div>';
  document.body.appendChild(panel);
  document.getElementById('ikrc-close').onclick = () => panel.remove();

  const body = document.getElementById('ikrc-body');

  authFetch('/api/empire').then(async (empire) => {
    const islands = empire.islands;
    const currentMatch = location.pathname.match(/\/island\/(\d+)/);
    const currentId = currentMatch ? Number(currentMatch[1]) : islands[0].id;

    body.innerHTML = ''
      + 'Insel: <select id="ikrc-island"></select><br><br>'
      + 'Typ: <select id="ikrc-type">'
      + '<option value="building">Gebäude</option>'
      + '<option value="research">Forschung</option>'
      + '<option value="ship">Schiff</option>'
      + '</select><br><br>'
      + 'Ziel: <select id="ikrc-target" style="width:100%"></select><br><br>'
      + '<span id="ikrc-level-label">Ziel-Stufe:</span> <input id="ikrc-level" type="number" min="1" value="1" style="width:60px"><br><br>'
      + '<button id="ikrc-calc" style="padding:4px 12px">Berechnen</button>'
      + '<div id="ikrc-result" style="margin-top:12px"></div>';

    const islandSel = document.getElementById('ikrc-island');
    islands.forEach(isl => {
      const opt = document.createElement('option');
      opt.value = isl.id; opt.textContent = isl.name;
      if (isl.id === currentId) opt.selected = true;
      islandSel.appendChild(opt);
    });

    let overview = null, research = null;

    async function loadTargets() {
      const islandId = islandSel.value;
      [overview, research] = await Promise.all([
        authFetch('/api/islands/' + islandId + '/overview'),
        authFetch('/api/research-overview'),
      ]);
      fillTargets();
    }

    function fillTargets() {
      const type = document.getElementById('ikrc-type').value;
      const targetSel = document.getElementById('ikrc-target');
      const levelInput = document.getElementById('ikrc-level');
      let list;
      if (type === 'building') list = overview.buildings;
      else if (type === 'research') list = research.researches;
      else list = overview.ships;
      targetSel.innerHTML = '';
      list.forEach(it => {
        const cur = it.level !== undefined ? it.level : it.count;
        const opt = document.createElement('option');
        opt.value = it.key;
        opt.dataset.cur = cur;
        opt.textContent = it.name + ' (aktuell ' + cur + (it.maxLevel ? '/' + it.maxLevel : '') + ')';
        targetSel.appendChild(opt);
      });
      // Bei Gebäuden/Forschung ist "level" die absolute Ziel-Stufe (have =
      // aktuelle Stufe). Bei Schiffen ist "level" dagegen die Anzahl NEU zu
      // bauender Schiffe — tech-path liefert dort have=0 unabhängig vom
      // Bestand. Deshalb unterschiedliches Default/Label je Typ.
      const levelLabel = document.getElementById('ikrc-level-label');
      const setLevelDefault = () => {
        const o = targetSel.selectedOptions[0];
        if (!o) return;
        if (type === 'ship') {
          levelLabel.textContent = 'Anzahl neu bauen:';
          levelInput.value = 1;
        } else {
          levelLabel.textContent = 'Ziel-Stufe:';
          levelInput.value = Number(o.dataset.cur) + 1;
        }
      };
      setLevelDefault();
      targetSel.onchange = setLevelDefault;
    }

    islandSel.onchange = loadTargets;
    document.getElementById('ikrc-type').onchange = fillTargets;
    await loadTargets();

    document.getElementById('ikrc-calc').onclick = async () => {
      const resultDiv = document.getElementById('ikrc-result');
      resultDiv.textContent = 'Rechne…';
      try {
        const islandId = islandSel.value;
        const targetKey = document.getElementById('ikrc-target').value;
        const level = document.getElementById('ikrc-level').value;
        const path = await authFetch('/api/islands/' + islandId + '/tech-path?target=' + targetKey + '&level=' + level);
        const isl = islands.find(i => i.id == islandId);

        // tech-path steps can echo the cost/time of an ALREADY-QUEUED order
        // (e.g. build queue length can raise cost/time) instead of what a
        // fresh order costs right now. Re-price every open step from the
        // live building/research/ship catalog so the numbers match "if I
        // order now". Falls back to the tech-path values only when a step
        // needs more than one level/unit at once (catalog only has the
        // single-next-level price).
        const liveCost = { wood: 0, stone: 0, iron: 0, coal: 0 };
        let liveSeconds = 0;
        let unverifiedSteps = [];
        for (const step of path.steps.filter(s => !s.done)) {
          const qty = step.need - step.have;
          let cost = null, seconds = null;
          if (step.type === 'building') {
            const b = overview.buildings.find(x => x.key === step.key);
            if (b && qty === 1) { cost = b.upgradeCost; seconds = b.buildTimeSeconds; }
          } else if (step.type === 'research') {
            const r = research.researches.find(x => x.key === step.key);
            if (r && qty === 1) { cost = r.upgradeCost; seconds = r.researchTimeSeconds; }
          } else if (step.type === 'ship') {
            const s = overview.ships.find(x => x.key === step.key);
            if (s && qty > 0) {
              cost = {};
              for (const k of Object.keys(liveCost)) cost[k] = (s.unitCost[k] || 0) * qty;
              seconds = s.buildTimeSeconds * qty;
            }
          }
          if (!cost || seconds === null) {
            // Mehrstufiger Sprung (qty > 1 bei Gebäude/Forschung): der
            // Katalog kennt nur den Preis für die nächste Stufe, nicht für
            // Zwischenstufen. Fallback auf tech-path — dessen Wert war bei
            // aktiv in der Warteschlange stehenden Zielen schon falsch,
            // hier daher als ungeprüft markieren statt stillschweigend zu
            // übernehmen.
            cost = step.cost; seconds = step.seconds;
            unverifiedSteps.push(step.name);
          }
          for (const k of Object.keys(liveCost)) liveCost[k] += cost[k] || 0;
          liveSeconds += seconds;
        }

        let maxHours = 0;
        let rows = '';
        let overCapacity = false;
        for (const [key, label] of RES) {
          const need = liveCost[key] || 0;
          const have = isl.resources[key] || 0;
          const perHour = isl.productionPerHour[key] || 0;
          const missing = Math.max(0, need - have);
          let hours;
          if (missing === 0) hours = 0;
          else if (perHour <= 0) hours = Infinity;
          else hours = missing / perHour;
          if (hours > maxHours) maxHours = hours;
          if (need > isl.capacity) overCapacity = true;
          rows += '<tr><td>' + label + '</td><td>' + need.toLocaleString() + '</td>'
            + '<td>' + have.toLocaleString() + '</td><td>' + perHour.toLocaleString() + '/h</td>'
            + '<td>' + fmtDuration(hours * 3600) + '</td></tr>';
        }

        const totalSeconds = (isFinite(maxHours) ? maxHours * 3600 : Infinity) + liveSeconds;

        resultDiv.innerHTML = ''
          + (unverifiedSteps.length ? '<div style="color:#f0c674;margin-bottom:6px">⚠️ Mehrstufiger Sprung bei ' + unverifiedSteps.join(', ') + ' — Wert stammt ungeprüft von tech-path, kann abweichen.</div>' : '')
          + (overCapacity ? '<div style="color:#f0c674;margin-bottom:6px">⚠️ Zielkosten übersteigen dein Lager (' + isl.capacity.toLocaleString() + ') — Lager ausbauen nötig.</div>' : '')
          + (path.steps.length > 1 ? '<div style="opacity:.8;margin-bottom:6px">Voraussetzungskette: ' + path.steps.filter(s=>!s.done).map(s=>s.name).join(' → ') + '</div>' : '')
          + '<table style="width:100%;border-collapse:collapse;font-size:12px">'
          + '<tr style="opacity:.7"><td>Rohstoff</td><td>Ziel</td><td>Hast</td><td>Prod.</td><td>Ansparzeit</td></tr>'
          + rows + '</table>'
          + '<div style="margin-top:8px;font-size:15px">Fertig in (inkl. längste Ansparzeit):<br><b>' + fmtDuration(totalSeconds) + '</b> (' + fmtHHMM(totalSeconds) + ')</div>';
      } catch (e) {
        resultDiv.textContent = 'Fehler: ' + e.message + ' (Token evtl. abgelaufen — Seite neu laden)';
      }
    };
  }).catch(e => {
    body.textContent = 'Fehler beim Laden: ' + e.message;
  });
})();
